function enterEmail()
{
	var email=document.getElementById("input1").value
		var emailLen=email.length
	  var regExp=/(?=.*[A-Za-z0-9@.]{1,})/
	
		if (emailLen == 0)
		{
		//show
		document.getElementById("show").innerHTML="please enter your email address"
		document.getElementById("show").style.color="red"
		document.getElementById("input1").style.borderColor="red"
        document.getElementById("l1").style.color="red"
		document.getElementById("l2").style.color="red"
		}
		else(email.match(regExp))
	{
			document.getElementById("input1").style.borderColor="green"
	}


}
function password()
{
	var pass=document.getElementById("input2").value
		var passwordLen=password.length
		var regEx=/(?=.*[A-Za-z0-9@.]{1,})/
		if (passwordLen == 0)
		{
		//show
		document.getElementById("pass").innerHTML="please enter your password"
		document.getElementById("pass").style.color="red"
		document.getElementById("input2").style.borderColor="red"
        document.getElementById("l3").style.color="red"
		
		}
		else(pass.match(regEx))
	{
			document.getElementById("input2").style.borderColor="green"
	}

}